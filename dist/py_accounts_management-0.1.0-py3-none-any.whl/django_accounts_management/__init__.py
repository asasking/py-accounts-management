default_app_config = 'django_accounts_management.apps.AccountLevelsConfig'

__version__ = '0.1.0'

__author__ = "asasking"
__email__ = "atugonzabilikwija@gmail.com"
